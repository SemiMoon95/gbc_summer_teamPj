﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPbar : MonoBehaviour {
    public GameObject bar_1;
    public GameObject bar_2;
    public GameObject bar_3;
    public GameObject bar_4;
    public GameObject bar_5;
    public GameObject bar_6;
    public GameObject bar_7;
    public GameObject bar_8;
    public GameObject bar_9;
    public GameObject bar_10;
    public GameObject bar_11;
    public GameObject temp;
    public int hp = 100;

    // Use this for initialization
    void Start () {
        bar_1.active = true;
        temp = bar_1;
        bar_2.active = false;
        bar_3.active = false;
        bar_4.active = false;
        bar_5.active = false;
        bar_6.active = false;
        bar_7.active = false;
        bar_8.active = false;
        bar_9.active = false;
        bar_10.active = false;
        bar_11.active = false;
    }
	
	// Update is called once per frame
	void Update () {
        switch (hp) {
            case 100:
                temp.active = false;
                temp = bar_1;
                temp.active = true;
                break;
    
            case 90:
                temp.active = false;
                temp = bar_2;
                temp.active = true;
                break;
            case 80:
                temp.active = false;
                temp = bar_3;
                temp.active = true;
                break;
            case 70:
                temp.active = false;
                temp = bar_4;
                temp.active = true;
                break;
            case 60:
                temp.active = false;
                temp = bar_5;
                temp.active = true;
                break;
            case 50:
                temp.active = false;
                temp = bar_6;
                temp.active = true;
                break;
            case 40:
                temp.active = false;
                temp = bar_7;
                temp.active = true;
                break;
            case 30:
                temp.active = false;
                temp = bar_8;
                temp.active = true;
                break;
            case 20:
                temp.active = false;
                temp = bar_9;
                temp.active = true;
                break;
            case 10:
                temp.active = false;
                temp = bar_10;
                temp.active = true;
                break;
            case 0:
                temp.active = false;
                temp = bar_11;
                temp.active = true;
                Application.LoadLevel("dead");
                break;
            default: break;
        }
	}
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Enemy")
        {
            hp -= 10;
        }
        if (col.gameObject.tag == "item2")
        {
            if (hp <= 98)
                hp += 2;
        }
        if (col.gameObject.tag == "item10")
        {
            if (hp == 98)
                hp += 2;
            if (hp == 96)
                hp += 4;
            if (hp == 94)
                hp += 6;
            if (hp == 92)
                hp += 8;
            if (hp <= 90)
                hp += 10;
        }
    }
}
